from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import TatsoulItem

#from datetime import date


class TatsoulSpider(CrawlSpider):

    name = "tatsoul"

    img_link = "https://www.tatsoul.com/supplies/"

    start_urls = [
                "https://www.tatsoul.com/supplies/"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=([".mean-menu-area.full-menu.d-none.d-lg-block .static.nav-item.dropdown  .nav-link.dropdown-toggle",".category-item  a"]))),
        Rule(LinkExtractor(restrict_css=(".image a")),callback="tatsoul"),  
    )


    def tatsoul(self, response):

        products = TatsoulItem()

        products["title"] = response.css("#productName::text").extract_first()

        try:
            products["price"] = response.css(".productBasePrice::text").extract_first().strip("\n")
        except:
            products["price"] = response.css(".productSpecialPrice::text").extract_first().strip("\n")

        products["model"] = response.css(".extra-info span:nth-child(2)::text").extract()

        products["description"] = response.css(".col-md-6+ .col-md-6 p::text").extract()

        if not products["description"]:
            products["description"] = response.css("#productDescription::text").extract()

        # if not products["description"]:
        #     products["description"] = response.css(".product-description.rte div::text").extract()

        # if not products["description"]:
        #     products["description"] = response.css(".product-description.rte::text").extract()



        products["images"] = response.css(".back.product-main-image__item img::attr(src)").extract()

        if not products["images"]:
            products["images"] = response.css(".additionalImages.centeredContent.back img::attr(src)").extract()

        for img in range(len(products["images"])):
            temp = self.img_link
            products["images"][img] = temp + products["images"][img]



        products["category"] = response.css(".breadcrumb-ul li:nth-child(2) a::text").extract_first()
        products["sub_category"] = response.css(".breadcrumb-ul li:nth-child(3) a::text").extract_first()
        products["sub_sub_category"] = response.css(".breadcrumb-ul li:nth-child(4) a::text").extract_first()

        products["url"] = response.url

        yield products
 